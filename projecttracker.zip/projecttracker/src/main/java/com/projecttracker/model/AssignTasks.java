package com.projecttracker.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "hr" ,name = "AssignTasks")
public class AssignTasks {
      
	  @Id
	  private int UserID;
	  @Column
	  private int TaskID;
      @Column
	  private String Tasks;
	  
	public AssignTasks()
	{
		
	}
	
	
	public AssignTasks(int userID, int taskID, String tasks) {
		super();
		UserID = userID;
		TaskID = taskID;
		Tasks = tasks;
	}


	public int getUserID() {
		return UserID;
	}
	public void setUserID(int userID) {
		UserID = userID;
	}
	public int getTaskID() {
		return TaskID;
	}
	public void setTaskID(int taskID) {
		TaskID = taskID;
	}
	public String getTasks() {
		return Tasks;
	}
	public void setTasks(String tasks) {
		Tasks = tasks;
	}
	@Override
	public String toString() {
		return "AssignTasks [UserID=" + UserID + ", TaskID=" + TaskID + ", Tasks=" + Tasks + "]";
	}
      
}
