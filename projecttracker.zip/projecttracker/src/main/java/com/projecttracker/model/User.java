package com.projecttracker.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "hr" ,name = "USER")
public class User {
    
	@Id
	private int UserId;
	@Column
	private String Name;
	@Column
	private int Age;
	@Column
	private String Designation;
	@Column
	private String Gender;
	@Column
	private String Email;
	@Column
	private String PhoneNo;
	@Column
	private int Salary;
	@Column
	private String Password;
	@Column
	private boolean Leader_Status;
	@Column
	private double Performance;
	
	
	
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public boolean isAdmin_Status() {
		return Leader_Status;
	}
	public void setAdmin_Status(boolean leader_Status) {
		Leader_Status = leader_Status;
	}
	public double getPerformance() {
		return Performance;
	}
	public void setPerformance(double performance) {
		Performance = performance;
	}
	
	
	
}
