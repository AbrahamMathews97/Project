package com.projecttracker.task.service;

import java.util.List;

import com.projecttracker.model.AssignTasks;

public interface AssignTasksService {
         public void addTasks(AssignTasks tasks);
         public void completedTasks(AssignTasks tasks);
         public List<AssignTasks> listTasks(int USERID);         
}
