package com.projecttracker.task.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projecttracker.model.AssignTasks;
import com.projecttracker.task.dao.TasksDAO;
import com.projecttracker.task.service.AssignTasksService;

@Service
public class AssignTasksServiceImpl implements AssignTasksService{
        
	@Autowired
	TasksDAO tasksdao;
	
	public void addTasks(AssignTasks tasks)
	{ tasksdao.save(tasks);
	}
	

	@Override
	public void completedTasks(AssignTasks tasks) {
		Optional<AssignTasks> deleted_tasks=tasksdao.findById(tasks.getTaskID());
		AssignTasks task=new AssignTasks();
		if(deleted_tasks.isPresent())
		{   
			task=deleted_tasks.get();
		}
		tasksdao.delete(task);
		
	}


	@Override
	public List<AssignTasks> listTasks(int USERID) {
		// TODO Auto-generated method stub
	 List<AssignTasks> listtasks=(List<AssignTasks>)tasksdao.findByUserID(USERID);
	 return listtasks;
	}
	
        
}
