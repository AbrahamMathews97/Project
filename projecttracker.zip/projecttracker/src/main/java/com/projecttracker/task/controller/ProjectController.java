package com.projecttracker.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.projecttracker.task.service.impl.AssignTasksServiceImpl;

@Controller
public class ProjectController {
        
	@Autowired
	AssignTasksServiceImpl tasksimpl;
	
	@RequestMapping("start")
	public ModelAndView loginpage()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("Login");
		return view;
	}
	
	@RequestMapping("NotAuthenticated")
	public ModelAndView notauthenticated()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("error");
		return view;
	}
	
	@RequestMapping("user")
	public ModelAndView user(int USERID)
	{
		ModelAndView view=new ModelAndView();
		List<AssignTasks> listtask=tasksimpl.listTasks(USERID);
		view.addObject();
		view.setViewName("normal_user");
		return view;
	}
	@RequestMapping("leader")
	public ModelAndView leader()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("leader");
		return view;
	}
	@RequestMapping("addTasks")
	public ModelAndView addTasks()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("redirect:/leader");
		return view;
	}
	
	public
	
	
}
