package com.projecttracker.task.service.impl;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projecttracker.model.AssignTasks;
import com.projecttracker.model.User;
import com.projecttracker.task.dao.TasksDAO;
import com.projecttracker.task.dao.UserDAO;
import com.projecttracker.task.service.AssignTasksService;

@Service
public class AssignTasksServiceImpl implements AssignTasksService{
        
	@Autowired
	TasksDAO tasksDAO;
	@Autowired
	UserDAO userDAO;
	
	public void addTasks(AssignTasks tasks)
	{ 
		tasksDAO.save(tasks);
	}
	

	@Override
	public void completedTasks(int taskId) {
		
		tasksDAO.deleteById(taskId);
		
	}


	@Override
	public List<AssignTasks> listTasks(int USERID) {
		// TODO Auto-generated method stub
	 List<AssignTasks> listtasks=(List<AssignTasks>)tasksDAO.findByusertaskId(USERID);
	 return listtasks;
	}


	public boolean authenticate(User user) {
		
		Integer enteredUserId=user.getUserId();
		System.out.println(enteredUserId);
		String enteredUserPassword=user.getPassword();
		System.out.println(enteredUserPassword);

		Optional<User> optional_dbUser=userDAO.findById(enteredUserId);
		
		if(optional_dbUser.isPresent()) {
			System.out.println("user exists check password");
			User dbUser=(User)optional_dbUser.get();
			
			if (dbUser.getPassword().equals(enteredUserPassword)) {
				System.out.println("valid user");
				return true;
			}
			else {
				System.out.println("incorrect password");
			}
		}else {
			System.out.println("id doesnt exist");
		}
		
		
		
		return false;
	}


	public boolean checkLeaderStatus(User user) {
		
		int enteredUserId=user.getUserId();
		
		Optional<User> optional_dbUser=userDAO.findById(enteredUserId);
		User dbUser=optional_dbUser.get();
		
		if(dbUser.isLeader_Status()==1) {
			//leader
			return true;
			
		}else {
			//user
			return false;
		}
		
	}
	
	public User userInfoById(int UserId)
	{
		Optional<User> optional_dbUser=userDAO.findById(UserId);
		User user=optional_dbUser.get();
		return user;
	}

			        
}
