package com.projecttracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjecttrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjecttrackerApplication.class, args);
	}

}
