package com.projecttracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjecttrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
